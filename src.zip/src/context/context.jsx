import { createContext, useState } from "react";
import runChat from "../config/gemini";

export const Context = createContext();

const ContextProvider = (props) => {
    const [prevPrompts, setPrevPrompts] = useState([]);
    const [input, setInput] = useState("");
    const [recentPrompt, setRecentPrompt] = useState("");
    const [showResult, setShowResult] = useState(false);
    const [loading, setLoading] = useState(false);
    const [resultData, setResultData] = useState("");
    const [error, setError] = useState(null);

    const delayPara = (index, nextWord) => {
        setTimeout(() => {
            setResultData(prev => prev + nextWord);
        }, 75 * index);
    };

    const onSent = async (prompt) => {
        try {
            setResultData("");
            setLoading(true);
            setShowResult(true);
            setError(null);
            
            const currentPrompt = prompt !== undefined ? prompt : input;
            
            if (!currentPrompt.trim()) {
                throw new Error("Please enter a valid prompt");
            }

            const response = await runChat(currentPrompt);
            
            if (response.startsWith("Error:")) {
                throw new Error(response);
            }

            if (prompt === undefined) {
                setPrevPrompts(prev => [...prev, input]);
            }
            setRecentPrompt(currentPrompt);

            // Process response with better error handling
            const formattedResponse = formatResponse(response);
            const words = formattedResponse.split(" ");
            
            words.forEach((word, index) => {
                delayPara(index, word + " ");
            });
        } catch (err) {
            console.error("Request Error:", err);
            setError(err.message);
            setResultData(err.message);
        } finally {
            setLoading(false);
            setInput("");
        }
    };

    const formatResponse = (text) => {
        try {
            let responseArray = text.split('**');
            let newArray = "";
            
            for (let i = 0; i < responseArray.length; i++) {
                newArray += i % 2 === 1 
                    ? `<b>${responseArray[i]}</b>` 
                    : responseArray[i];
            }
            
            return newArray.split('*').join("<br/>");
        } catch (err) {
            console.error("Formatting Error:", err);
            return text; // Return original if formatting fails
        }
    };

    const newChat = () => {
        setLoading(false);
        setShowResult(false);
        setResultData("");
        setError(null);
    };

    const contextValue = {
        prevPrompts,
        setPrevPrompts,
        onSent,
        setRecentPrompt,
        recentPrompt,
        showResult,
        loading,
        resultData,
        input,
        setInput,
        newChat,
        error
    };

    return (
        <Context.Provider value={contextValue}>
            {props.children}
        </Context.Provider>
    );
};

export default ContextProvider;